﻿using HtmlAgilityPack;
using MultiSourceTorrentDownloader.Data;
using MultiSourceTorrentDownloader.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiSourceTorrentDownloader.Services
{
    public class $fileinputname$Parser : ParserBase, I$fileinputname$Parser
    {
        private readonly ILogService _logger;

        public $fileinputname$Parser(ILogService logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<TorrentQueryResult> ParsePageForTorrentEntries(string pageContents)
        {
            throw new NotImplementedException();
        }
    }
}
