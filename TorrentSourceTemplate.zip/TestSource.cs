﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiSourceTorrentDownloader.Services
{
    public class $fileinputname$Source : SourceBase, I$fileinputname$Source
    {
        private readonly ILogService _logger;
        private readonly I$fileinputname$Parser _parser;
        public $fileinputname$Source(ILogService logger, I$fileinputname$Parser parser)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _parser = parser ?? throw new ArgumentNullException(nameof(parser));

            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromMilliseconds(5000);
            _baseUrl = ConfigurationManager.AppSettings["$fileinputname$Url"];
            _searchEndpoint = Path.Combine(_baseUrl, ConfigurationManager.AppSettings["$fileinputname$SearchEndpoint"]);
        }
    }
}
